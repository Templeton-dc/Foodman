# Foodman_17-02-24
Learn to craft a stunning, responsive restaurant landing page from scratch with HTML, CSS, and JavaScript!
